const express = require("express");
const path = require('path');
const app = express();
const mongoose = require("mongoose");
var bodyParser = require("body-parser");

app.use(express.static("build"));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
require("./routes")(app);
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname + '/index.html'));
})


//connect to mongodb
mongoose
  .connect(process.env.MONGODB_URI || "mongodb://localhost/api", {
    useNewUrlParser: true
  })
  .then(() => {
    console.log("Mongo is connected");
  })
  .catch(err => {
    console.log(err);
    console.log("\x1b[31m\x1b[1m MongoDB Not Connected");
  });



app.listen(8080, () => console.log("Listening on port 8080!"));
