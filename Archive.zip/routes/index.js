module.exports=function(app){
    app.use("/main",require("./main"))
}